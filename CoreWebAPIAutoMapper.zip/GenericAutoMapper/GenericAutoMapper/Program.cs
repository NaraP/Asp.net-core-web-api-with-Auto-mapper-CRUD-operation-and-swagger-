﻿using System;

namespace GenericAutoMapper
{

    class Program
    {

        static void Main(string[] args)
        {

            Teacher_Interview ti = new Teacher_Interview()
            {
                UID = 101,
                Name = "Faisal Pathan",
                Email = "faisalmpathan@gmail.com",
                Subject = ".NET"
            };

            Teacher_College tcObject = new Teacher_College();
            tcObject.TID = ti.UID;
            tcObject.Name = ti.Name;
            tcObject.Email = ti.Email;
            object obj = tcObject;

           // var records = (ti).MapProperties<obj>();


        }
    }
}
