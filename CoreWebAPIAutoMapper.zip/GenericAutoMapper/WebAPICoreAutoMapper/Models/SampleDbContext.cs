﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebAPICoreAutoMapper.Models
{
    public partial class SampleDbContext : DbContext
    {
        public SampleDbContext()
        {
        }

        public SampleDbContext(DbContextOptions<SampleDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<ExceptionLog> ExceptionLog { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseNpgsql("User ID =postgres;Password=admin;Server=localhost;Port=5432;Database=SampleDb;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.ToTable("employee");

                entity.Property(e => e.EmployeeId)
                    .HasColumnName("employee_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.City)
                    .HasColumnName("city")
                    .HasMaxLength(50);

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.Department)
                    .HasColumnName("department")
                    .HasMaxLength(50);

                entity.Property(e => e.Gender)
                    .HasColumnName("gender")
                    .HasMaxLength(500);

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");
            });

            modelBuilder.Entity<ExceptionLog>(entity =>
            {
                entity.HasKey(x => x.ExceptionId)
                    .HasName("pk_exception_log");

                entity.ToTable("exception_log");

                entity.Property(e => e.ExceptionId)
                    .HasColumnName("exception_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.ActionName)
                    .IsRequired()
                    .HasColumnName("action_name")
                    .HasMaxLength(100);

                entity.Property(e => e.ControllerName)
                    .IsRequired()
                    .HasColumnName("controller_name")
                    .HasMaxLength(100);

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.ExceptionMsg)
                    .IsRequired()
                    .HasColumnName("exception_msg")
                    .HasMaxLength(5000);

                entity.Property(e => e.ExceptionSource)
                    .IsRequired()
                    .HasColumnName("exception_source")
                    .HasMaxLength(5000);

                entity.Property(e => e.ExceptionTs).HasColumnName("exception_ts");

                entity.Property(e => e.ExceptionType)
                    .IsRequired()
                    .HasColumnName("exception_type")
                    .HasMaxLength(1000);

                entity.Property(e => e.ExceptionUrl)
                    .IsRequired()
                    .HasColumnName("exception_url")
                    .HasMaxLength(500);

                entity.Property(e => e.RemoteIpAddr)
                    .HasColumnName("remote_ip_addr")
                    .HasMaxLength(500);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
