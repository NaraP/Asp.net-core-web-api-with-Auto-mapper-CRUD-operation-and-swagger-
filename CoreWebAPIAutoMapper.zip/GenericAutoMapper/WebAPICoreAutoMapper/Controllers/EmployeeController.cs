﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPICoreAutoMapper.Dto;
using WebAPICoreAutoMapper.Models;

namespace WebAPICoreAutoMapper.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //https://sensibledev.com/asp-net-core-automapper/
        //https://www.toptal.com/asp-dot-net/asp-net-web-api-tutorial uesefull link
        private readonly SampleDbContext _sampleDbContext;

        private readonly IMapper _mapper;

        public EmployeeController(SampleDbContext sampleDbContext, IMapper mapper)
        {
            _sampleDbContext = sampleDbContext;
            _mapper = mapper;

        }
        // GET: api/Employee
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpGet("GetAllEmployees", Name = nameof(GetAllEmployees))]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<ActionResult> GetAllEmployees()
        {
            var employee = await _sampleDbContext.Employee.ToListAsync();

            try
            {
                var result= _mapper.Map<IEnumerable<EmployeeDto>>(employee);

                return Ok(result);
            }
            catch(Exception ex)
            {

            }
            return Ok();
        }

        [HttpPost("CreateEmployee", Name = nameof(CreateEmployee))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        public async Task<ActionResult> CreateEmployee([FromBody] EmployeeDto employeeDto)
        {
            try
            {
                //var emp = _mapper.Map<IEnumerable<Employee>>(employeeDto);

                var employee = _mapper.Map<EmployeeDto, Employee>(employeeDto);

                employee.EmployeeId = Guid.NewGuid();
                //var result = _mapper.Map<Employee>(employeeDto);

                await _sampleDbContext.AddAsync(employee);
                await _sampleDbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
            }
            return Ok();
        }

        [HttpDelete("UpdateEmployee", Name = nameof(UpdateEmployee))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        public async Task<ActionResult> UpdateEmployee([FromBody] EmployeeDto employeeDto)
        {
            Employee employee = await _sampleDbContext.Employee.AsNoTracking().Where(e => e.EmployeeId.Equals(employeeDto.EmployeeId)).FirstOrDefaultAsync(); ;

            var emp = _mapper.Map<EmployeeDto, Employee>(employeeDto);

            _sampleDbContext.Entry<Employee>(emp).State = EntityState.Modified;

            // _sampleDbContext.Entry(emp).State = EntityState.Modified;

            await _sampleDbContext.SaveChangesAsync();

            return Ok(200);
        }

        [HttpPost("DeleteEmployee", Name = nameof(DeleteEmployee))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        public async Task<ActionResult> DeleteEmployee([FromBody] EmployeeDto employeeDto)
        {
            Employee employee = await _sampleDbContext.Employee.AsNoTracking().Where(e => e.EmployeeId.Equals(employeeDto.EmployeeId)).FirstOrDefaultAsync(); ;

            var emp = _mapper.Map<EmployeeDto, Employee>(employeeDto);

            _sampleDbContext.Entry<Employee>(emp).State = EntityState.Deleted;

            // _sampleDbContext.Entry(emp).State = EntityState.Modified;

            await _sampleDbContext.SaveChangesAsync();

            return Ok(200);
        }
    }
}
