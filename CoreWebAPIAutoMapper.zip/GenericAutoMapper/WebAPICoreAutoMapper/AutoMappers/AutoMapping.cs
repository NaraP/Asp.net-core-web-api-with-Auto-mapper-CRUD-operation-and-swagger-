﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPICoreAutoMapper.Dto;
using WebAPICoreAutoMapper.Models;

namespace WebAPICoreAutoMapper.AutoMappers
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
            CreateMap<Employee, EmployeeDto>(); // means you want to map from User to UserDTO

            CreateMap<EmployeeDto, Employee>();

        }
    }
}
